﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OfficeOpenXml;

namespace FileHandlingProgram
{
    class SpreadsheetRead
    {
        //List<string> ExcelReader()
        //{
        //    string spreadsheetPath = "activities.xlsx";
        //    FileInfo spreadsheetInfo = new FileInfo(spreadsheetPath);
        //    Stream newStream = new Stream();
        //    Stream stream =
        //    ExcelPackage pck = new ExcelPackage();
        //    pck.Load();
        //}



        public void ExcelReader()
        {
            string spreadsheetPath = "activities.xlsx";
            FileInfo spreadsheetInfo = new FileInfo(spreadsheetPath);
            var package = new ExcelPackage(spreadsheetInfo);
            ExcelWorksheet workSheet = package.Workbook.Worksheets[1];

            for (int i = workSheet.Dimension.Start.Row; i <= workSheet.Dimension.End.Row; i++)
            {
                for (int j = workSheet.Dimension.Start.Column; j <= workSheet.Dimension.End.Column; j++)
                {
                    object cellValue = workSheet.Cells[i, j].Value;
                    System.Windows.Forms.MessageBox.Show((string)cellValue);
                }

            }
        }




    }
}




