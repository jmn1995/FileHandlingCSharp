﻿namespace FileHandlingProgram
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Insantiate = new System.Windows.Forms.Button();
            this.Instantiate = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Insantiate
            // 
            this.Insantiate.Location = new System.Drawing.Point(23, 30);
            this.Insantiate.Name = "Insantiate";
            this.Insantiate.Size = new System.Drawing.Size(200, 111);
            this.Insantiate.TabIndex = 0;
            this.Insantiate.Text = "Create Spreadsheet";
            this.Insantiate.UseVisualStyleBackColor = true;
            this.Insantiate.Click += new System.EventHandler(this.button1_Click);
            // 
            // Instantiate
            // 
            this.Instantiate.Location = new System.Drawing.Point(267, 30);
            this.Instantiate.Name = "Instantiate";
            this.Instantiate.Size = new System.Drawing.Size(223, 111);
            this.Instantiate.TabIndex = 1;
            this.Instantiate.Text = "Insantiate to Class";
            this.Instantiate.UseVisualStyleBackColor = true;
            this.Instantiate.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(538, 30);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(199, 111);
            this.button1.TabIndex = 2;
            this.button1.Text = "Read Excel File";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DimGray;
            this.ClientSize = new System.Drawing.Size(775, 450);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.Instantiate);
            this.Controls.Add(this.Insantiate);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button Insantiate;
        private System.Windows.Forms.Button Instantiate;
        private System.Windows.Forms.Button button1;
    }
}

