﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace FileHandlingProgram
{
    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var activities = new List<Activity>()
                    {
                        new Activity() {Name ="Working", MondayHours =8, TuesdayHours =8, WednesdayHours = 8},
                        new Activity() {Name ="Excercising", MondayHours =1, TuesdayHours =8, WednesdayHours = 1},
                        new Activity() {Name ="Sleeping", MondayHours =6, TuesdayHours =7, WednesdayHours = 8}

                };
            //CreateSpreadsheet(activities); 

            SpreadsheetCall mySpreadsheetCall = new SpreadsheetCall();
            mySpreadsheetCall.MakeSpreadsheet(activities);

            MessageBox.Show("all done");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            ExcelCreator excelCreator = new ExcelCreator();

            //ExcelCreator.printInstance(); < call to the static method
            //excelCreator.printInstance(); <This will print instance but returns a string to nothing
            string makeOutputString = excelCreator.printInstance(); // returns a string into the string object created
            //Call on printInput(), give it an input string, and print the output

            //use class instance and call its method to return a string
            //print the returned string here
            MessageBox.Show(makeOutputString);
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            SpreadsheetRead tableCall = new SpreadsheetRead();

            tableCall.ExcelReader();

            





        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            string path = Environment.CurrentDirectory + "/" + "FileCreated.txt";
            if (!File.Exists(path))
            {
                var textFile = File.CreateText(path);
                textFile.Close();
                MessageBox.Show("File created sucessfully");
                
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string path = Environment.CurrentDirectory + "/" + "FileCreated.txt";
            using (StreamWriter sw = new StreamWriter(path))
            {

               
                sw.WriteLine("This is the file created to be written on.");
                MessageBox.Show("File can now be rewritten.");
            }
        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            string path = Environment.CurrentDirectory + "/" + "FileCreated.txt";
            using (StreamReader sr = new StreamReader(path))
            {
                var readTextFile = File.CreateText(path);
                readTextFile.Close();
                string text = sr.ReadLine();
                richTextBox1.Text = text;
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
    }

