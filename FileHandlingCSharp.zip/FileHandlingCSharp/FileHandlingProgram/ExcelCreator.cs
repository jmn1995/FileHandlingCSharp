﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FileHandlingProgram
{
    class ExcelCreator
    {
        //create method that returns any string (make one up)
        public string printInstance()  //change method to return a string
        {
            //create string here
            string makeString = "This is the method inside of the instance.";


            //return string here
            return makeString;


        }
    }
}


       //input a string, and return that same string
       // public ____ printInput(____)
        

         //   return _____;
        

    

