﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OfficeOpenXml;
using System.IO;

namespace FileHandlingProgram
{
    class SpreadsheetCall
    {
        public void MakeSpreadsheet(List<Activity> activities)
        {
            string spreadsheetPath = "activities.xlsx";
            File.Delete(spreadsheetPath);
            FileInfo spreadsheetInfo = new FileInfo(spreadsheetPath);

            ExcelPackage pck = new ExcelPackage(spreadsheetInfo);
            var activitiesWorksheet = pck.Workbook.Worksheets.Add("Activities");
            activitiesWorksheet.Cells["A1"].Value = "Name";
            activitiesWorksheet.Cells["B1"].Value = "Monday";
            activitiesWorksheet.Cells["C1"].Value = "Tuesday";
            activitiesWorksheet.Cells["D1"].Value = "Wednesday";
            activitiesWorksheet.Cells["A1:D1:"].Style.Font.Bold = true;

            // data information
            int currentRow = 2;
            foreach (var activity in activities)
            {
                activitiesWorksheet.Cells["A" + currentRow.ToString()].Value = activity.Name;
                activitiesWorksheet.Cells["B" + currentRow.ToString()].Value = activity.MondayHours;
                activitiesWorksheet.Cells["C" + currentRow.ToString()].Value = activity.TuesdayHours;
                activitiesWorksheet.Cells["D" + currentRow.ToString()].Value = activity.WednesdayHours;

                currentRow++;

            }

            activitiesWorksheet.View.FreezePanes(2, 1);

            activitiesWorksheet.Cells["B" + (currentRow).ToString()].Formula = "SUM(B2:B" + (currentRow - 1).ToString() + ")";
            activitiesWorksheet.Cells["C" + (currentRow).ToString()].Formula = "SUM(C2:C" + (currentRow - 1).ToString() + ")";
            activitiesWorksheet.Cells["D" + (currentRow).ToString()].Formula = "SUM(D2:D" + (currentRow - 1).ToString() + ")";
            activitiesWorksheet.Cells["B" + (currentRow).ToString()].Style.Font.Bold = true;
            activitiesWorksheet.Cells["C" + (currentRow).ToString()].Style.Font.Bold = true;
            activitiesWorksheet.Cells["D" + (currentRow).ToString()].Style.Font.Bold = true;
            activitiesWorksheet.Cells["B" + (currentRow).ToString()].Style.Border.Top.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
            activitiesWorksheet.Cells["C" + (currentRow).ToString()].Style.Border.Top.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;
            activitiesWorksheet.Cells["D" + (currentRow).ToString()].Style.Border.Top.Style = OfficeOpenXml.Style.ExcelBorderStyle.Thin;

            pck.Save();


        }
    }
}
